from src.Connection import Connection

connection = Connection()


class DBManipulation:
    def __init__(self):
        self.samples = {}
        self.conn = connection.con
        self.isTested=connection.testConnection()

    def fetchAll(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM dataset")
            result = cursor.fetchall()
            for row in result:
                print(row)
        except:
            print("Unable to fetch from database..")

    def fetchSample(self, fname):
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT Count(*)"
                           " FROM dataset"
                           " where `firstname`='{}'".format(fname))
            result = cursor.fetchone()
            countRows = result[0]
            print(fname)
            return countRows
        except:
            print("Unable to fetch from database..")
            return

    def insertSample(self,fname, lname, folderURL):
        count = self.fetchSample(fname)

        if count is None or count==0:
            print("User not found !")
            print("Adding a new record please wait..")
            cursor = self.conn.cursor()
            query = "INSERT INTO dataset(firstname,lastname,folderURL) " \
                    "VALUES (%s,%s,%s);"
            values = (fname, lname, folderURL)
            cursor.execute(query, values)
            self.conn.commit()  # to save to db
            print(cursor.rowcount, "record inserted..")
        else:
            print("Username already exists !")

    def closeCon(self):
        self.conn = None
        print("Disconnected from mysql server..")

# manipulation = DBManipulation()
