import os
from tkinter import *
from tkinter import ttk

import cv2
from PIL import Image, ImageTk
from face_recognition.api import face_detector

from src.DBManipulation import DBManipulation
from src.quickstart import GoogleDriveService


class addUnRecoPage:
    # Function for opening the
    # file explorer window

    def __init__(self, root, importedimage):
        addUnWindow = Toplevel(root)
        addUnWindow.geometry('500x300')
        addUnWindow.resizable(0, 0)
        addUnWindow.wm_iconbitmap('img/import.ico')  # the img for the root, metel favicon
        addUnWindow.title('IMPORT SAMPLE')
        addUnWindow.configure(bg='#D3D3D3')
        self.oldName = ""
        self.manipulation = DBManipulation()
        self.service = GoogleDriveService()
        self.service.downloadDataset()
        self.img = importedimage
        if self.img.any():
            print('img exists')
        else:
            print('img not exist')

        # Bg img
        image = Image.open('img/import.jpg')
        self.copy_of_image = image.copy()
        photo = ImageTk.PhotoImage(image)
        self.label1 = ttk.Label(addUnWindow, image=photo)
        self.label1.bind('<Configure>', self.resize_image)
        self.label1.pack(fill=BOTH, expand=YES)

        # Labels

        fnameLabel = Label(addUnWindow, text='FIRSTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        fnameLabel.place(x=20, y=100)

        lnameLabel = Label(addUnWindow, text='LASTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        lnameLabel.place(x=20, y=150)

        # Storing Variables
        self.firstname = StringVar()
        self.lastname = StringVar()

        # Entries
        fnameEntry = Entry(addUnWindow, textvariable=self.firstname, bg="#D3D3D3")
        fnameEntry.place(x=250, y=100)
        lnameEntry = Entry(addUnWindow, textvariable=self.lastname, bg="#D3D3D3")
        lnameEntry.place(x=250, y=150)

        # Buttons
        self.button_explore = Button(addUnWindow,
                                     text="ADD",
                                     command=(lambda: self.addNotRecognized(self.firstname.get(), self.lastname.get(),
                                                                            self.img)))
        self.button_explore.place(x=200, y=220)
        addUnWindow.mainloop()

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        image = self.copy_of_image.resize((new_width, new_height))
        photo = ImageTk.PhotoImage(image)
        self.label1.config(image=photo)
        self.label1.image = photo  # avoid garbage collection

    def getTargetPath(self, fileName):
        filenameZip = fileName.split("/")[-1]
        print(filenameZip)

        self.oldName = filenameZip[:-4]  # remove .zip extension
        # targetPath = fileName + "/" + self.oldName
        # return targetPath

    def addNotRecognized(self, firstname, lastname, myimg):
        face_det = cv2.CascadeClassifier('Cascades/haarcascade_frontalface_default.xml')
        folderId = self.service.createFolder(str(firstname))
        directory = str(firstname)
        parent_dir = 'dataset'
        path = os.path.join(parent_dir, directory)
        # print(path)
        folderExists = os.path.exists(path)
        if not folderExists:
            os.mkdir(path)
        while (True):
            gray = cv2.cvtColor(myimg, cv2.COLOR_BGR2GRAY)
            faces = face_det.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv2.rectangle(myimg, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.imwrite(
                    "dataset/{0}/{1}{2}.jpg".format(str(self.firstname), str(self.firstname), str(self.lastname),
                                                    gray[y:y + h, x:x + w]))
            if myimg is not None:
                print("Image successfully saved..")
            else:
                print("Unable to save image..")
            k = cv2.waitKey(100) & 0xff  # Press 'ESC' for exiting video
            if k == 27:
                # Do a bit of cleanup
                break
        print("\n [INFO] Exiting Program and cleanup stuff..")
        cv2.destroyAllWindows()
