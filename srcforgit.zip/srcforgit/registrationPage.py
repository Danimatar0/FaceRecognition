from tkinter import *

from PIL import Image, ImageTk
import cv2
from igAPI import instagramAPI
from src.DBManipulation import DBManipulation
from src.addPage import addPage
from src.faceDataset import Dataset
from src.faceRecognition import Recognizing
from src.faceTraining import Training
from src.facebookAPI import facebookAPI
from src.importDataset import importPage
from tkinter import messagebox as mb, filedialog, ttk


class RegistrationPage:
    def __init__(self):
        # action = DBManipulation
        self.root = Tk()  # root is the window
        self.root.geometry('700x500')
        self.root.resizable(1, 1)
        self.root.wm_iconbitmap('img/registration.ico')  # the img for the root, metel favicon
        self.root.title('REGISTRATION PAGE')
        self.root.configure(bg='#D3D3D3')
        image = Image.open('img/frBg.png')
        self.copy_of_image = image.copy()
        photo = ImageTk.PhotoImage(image)
        self.label = ttk.Label(self.root, image=photo)
        self.label.bind('<Configure>', self.resize_image)
        self.label.pack(fill=BOTH, expand=YES)

        addButton = Button(self.root, text='ADD', font=('normal', 10), bd=3, command=(lambda: self.openAddWindow(self.root)))
        addButton.place(x=20, y=220)

        importButton = Button(self.root, text='IMPORT', font=('normal', 10), bd=3,
                              command=(lambda: self.openImportWindow(self.root)))
        importButton.place(x=20, y=300)

        # trainButton = Button(root, text='TRAIN', font=('normal', 10), bd=3,
        #                      command=(lambda: self.trainModel()))
        # trainButton.place(x=80, y=220)
        # Dropdown Menu
        # Dropdown menu options
        options = ["Import Existing", "Capture"]
        # datatype of menu text
        self.clicked = StringVar()
        # initial menu text
        self.clicked.set("Select Source")
        # Create Dropdown menu
        drop = OptionMenu(self.root, self.clicked, *options)
        drop.place(x=20, y=380)

        recognizeButton = Button(self.root, text='RECOGNIZE', font=('normal', 10), bd=3,
                                 command=(lambda: self.checkOptions()))
        recognizeButton.place(x=150, y=380)

        fetchIGButton = Button(self.root, text='FETCH FROM INSTAGRAM', font=('normal', 10), bd=3,
                               command=(lambda: self.fetchInstaProfile()))
        fetchIGButton.place(x=200, y=300)
        self.root.mainloop()

    def openAddWindow(self, root):
        addPage(self.root)

    def openImportWindow(self, root):
        importPage(self.root)


    def checkOptions(self):
        selectedItem = self.clicked.get()
        recognizer = Recognizing(self.root)

        if selectedItem == "Import Existing":
            path = self.browseSource()
            recognizer.RecognizeExisting(path)
        elif selectedItem == "Capture":
            recognizer.RecognizeLive()
        else:
            mb.showerror("Error", "Kindly Choose A Method For Recognition..")

    def browseSource(self):
        filename = filedialog.askopenfilename(initialdir="/",
                                              title="Select a File",
                                              filetypes=(("Images",
                                                          "*.png*"),
                                                         ("Images",
                                                          "*.jpeg*"),
                                                         ("Images",
                                                          "*.jpg*"),
                                                         ("Images",
                                                          "*.gif*")))
        # print(filename)
        print("File successfully imported..")
        return filename

    def fetchLikes(self):
        fbapi = facebookAPI()
        fbapi.get_likes_api()

    def fetchFriends(self):
        api = facebookAPI()
        api.getFriendsList()

    def fetchInstaProfile(self):
        instaapi = instagramAPI()
        instaapi.fetchProfile()
        trainer = Training()
        trainer.train()

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        image = self.copy_of_image.resize((new_width, new_height))
        photo = ImageTk.PhotoImage(image)
        self.label.config(image=photo)
        self.label.image = photo  # avoid garbage collection

register = RegistrationPage()
register.__init__()
