import face_recognition
import imutils
import pickle
import time
import cv2
import os

from src.addUnReco import addUnRecoPage
from src.faceDataset import Dataset
from tkinter import messagebox as mb, filedialog, ttk

from src.importDataset import importPage


class Recognizing:

    def __init__(self,root):
        self.root=root

    def RecognizeExisting(self,path):
        # find path of xml file containing haarcascade file
        faceCascade = cv2.CascadeClassifier('Cascades/haarcascade_frontalface_default.xml')
        # load the known faces and embeddings saved in last file
        data = pickle.loads(open('trainer/faceEncoding.pickle', "rb").read())
        # Find path to the image you want to detect face and pass it here
        image = cv2.imread(path)
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        # convert image to Greyscale for haarcascade
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray,
                                             scaleFactor=1.1,
                                             minNeighbors=5,
                                             minSize=(60, 60),
                                             flags=cv2.CASCADE_SCALE_IMAGE)

        # the facial embeddings for face in input
        encodings = face_recognition.face_encodings(rgb)
        names = []
        recognized=False
        # loop over the facial embeddings incase
        # we have multiple embeddings for multiple fcaes
        for encoding in encodings:
            # Compare encodings with encodings in data["encodings"]
            # Matches contain array with boolean values and True for the embeddings it matches closely
            # and False for rest
            matches = face_recognition.compare_faces(data["encodings"],
                                                     encoding)
            # set name =unknown if no encoding matches
            name = "Unknown"
            # check to see if we have found a match
            if True in matches:
                # Find positions at which we get True and store them
                matchedIdxs = [i for (i, b) in enumerate(matches) if b]
                counts = {}
                # loop over the matched indexes and maintain a count for
                # each recognized face face
                for i in matchedIdxs:
                    # Check the names at respective indexes we stored in matchedIdxs
                    name = data["names"][i]
                    # increase count for the name we got
                    counts[name] = counts.get(name, 0) + 1
                    # set name which has highest count
                    name = max(counts, key=counts.get)

                # update the list of names
                names.append(name)
                # loop over the recognized faces
                for ((x, y, w, h), name) in zip(faces, names):
                    # rescale the face coordinates
                    # draw the predicted face name on the image
                    cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    cv2.putText(image, name, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
                                0.75, (0, 0, 255), 2)
                    recognized=True
            cv2.imshow("Frame", image)
            if not recognized:
                mb.Message(master=None)
                mb.askyesno(title='Recognize', message='Face not recognized, would you like to add it?')
                if mb.YES:
                    self.openAddUnWindow(self.root,image)
                elif mb.NO:
                    cv2.destroyAllWindows()

            cv2.waitKey(0)

    def openAddUnWindow(self, root,img):
        addUnRecoPage(root,img)

    def RecognizeLive(self):
        # find path of xml file containing haarcascade file
        faceCascade = cv2.CascadeClassifier('Cascades/haarcascade_frontalface_default.xml')
        # load the known faces and embeddings saved in last file
        cam = cv2.VideoCapture(0)  # first webcam
        cam.set(3, 640)  # set video width
        cam.set(4, 480)  # set video height
        print("\n [INFO] Initializing face capture. Look the camera and wait ...")
        count = 0
        while (True):
            ret, img = cam.read()
            print("\n [INFO] Capturing photo, Please stay steady..")
            self.rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            # convert image to Greyscale for haarcascade
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = faceCascade.detectMultiScale(gray,
                                                 scaleFactor=1.1,
                                                 minNeighbors=5,
                                                 minSize=(60, 60),
                                                 flags=cv2.CASCADE_SCALE_IMAGE)
            print("\n [INFO] Image captured, Recognizing your face, Please wait..")
            count += 1
            k = cv2.waitKey(100) & 0xff  # Press 'ESC' for exiting video
            if k == 27:
                break
            elif count >= 1:  # Take 1 face capture and stop video
                break
        # Do a bit of cleanup
        print("\n [INFO] Exiting Program and cleanup stuff..")
        cam.release()
        # cv2.destroyAllWindows()
        data = pickle.loads(open('trainer/faceEncoding.pickle', "rb").read())
        # the facial embeddings for face in input
        encodings = face_recognition.face_encodings(self.rgb)
        names = []
        # loop over the facial embeddings incase
        # we have multiple embeddings for multiple fcaes
        for encoding in encodings:
            # Compare encodings with encodings in data["encodings"]
            # Matches contain array with boolean values and True for the embeddings it matches closely
            # and False for rest
            matches = face_recognition.compare_faces(data["encodings"],
                                                     encoding)
            # set name =unknown if no encoding matches
            name = "Unknown"
            # check to see if we have found a match
            if True in matches:
                # Find positions at which we get True and store them
                matchedIdxs = [i for (i, b) in enumerate(matches) if b]
                counts = {}
                # loop over the matched indexes and maintain a count for
                # each recognized face face
                for i in matchedIdxs:
                    # Check the names at respective indexes we stored in matchedIdxs
                    name = data["names"][i]
                    # increase count for the name we got
                    counts[name] = counts.get(name, 0) + 1
                    # set name which has highest count
                    name = max(counts, key=counts.get)

                # update the list of names
                names.append(name)
                # loop over the recognized faces
                for ((x, y, w, h), name) in zip(faces, names):
                    # rescale the face coordinates
                    # draw the predicted face name on the image
                    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.putText(img, name, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
                                0.75, (0, 255, 0), 2)
            cv2.imshow("Frame", img)
            cv2.waitKey(0)



