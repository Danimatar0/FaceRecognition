from __future__ import print_function

import io
import os.path
import shutil
import subprocess
import time
import webbrowser
from os import chmod
import stat

from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload


class GoogleDriveService:
    def __init__(self):
        # If modifying these scopes, delete the file token.json.
        SCOPES = ['https://www.googleapis.com/auth/drive']
        creds = None
        # The file token.json stores the user's access and refresh tokens, and is
        # created automatically when the authorization flow completes for the first
        # time.
        if os.path.exists('token.json'):
            creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open('token.json', 'w') as token:
                token.write(creds.to_json())

        service = build('drive', 'v3', credentials=creds)  # creating the service
        self.googleService = service
        # print(self.googleService)
        # Call the Drive v3 API
        # results = self.googleService.files().list(
        #     pageSize=10, fields="nextPageToken, files(id, name)").execute()
        # print(results)
        # items = results.get('files', [])
        self.datasetId = self.createDatasetFolder()
        print("Dataset id :", self.datasetId)

    def listAllFiles(self):
        results = self.googleService.files().list(
            pageSize=50, fields="nextPageToken, files(id, name)").execute()
        items = results.get('files', [])

        if not items:
            print('No files found.')
        else:
            print('Files:')
            for item in items:
                # print('{}'.format(item.get('parents')))
                print(u'{0} ({1})'.format(item['name'], item['id']))

    def searchFolder(self, size, folderName):
        results = self.googleService.files().list(
            pageSize=size, fields="nextPageToken,files(id,name)").execute()
        items = results.get('files', [])
        if not items:
            print('No Files Found.')
        else:
            for item in items:
                # print(item.get('parent'))
                if item.get('name') == folderName:
                    folderId = item.get('id')
                    return folderId
            else:
                return None

    def createDatasetFolder(self):
        exists = self.searchFolder(100, "dataset")
        if not exists:
            file_metadata = {
                'name': 'dataset',
                'mimeType': 'application/vnd.google-apps.folder',
            }
            folder = self.googleService.files().create(body=file_metadata,
                                                       fields='id,name').execute()
            return folder.get('id')
        else:
            print("Dataset folder already exists..")
            return "1Z6NAnW5gdoYBn5CmrFgwnaGN_WzTnqpU"

    def createFolder(self, folderName):
        datasetId = self.datasetId
        file_metadata = {
            'name': folderName,
            'mimeType': 'application/vnd.google-apps.folder',
            'parents': [datasetId]
        }
        folder = self.googleService.files().create(body=file_metadata,
                                                   fields='id').execute()
        return folder.get('id')

    def uploadFile(self, fileName, filePath, mimetype, parentID):
        file_metadata = {
            'name': fileName,
            'parents': [parentID]
        }
        media = MediaFileUpload(filePath, mimetype=mimetype)
        file = self.googleService.files().create(body=file_metadata,
                                                 media_body=media,
                                                 fields='id').execute()
        print("Image id :", file.get('id'))

    def downloadFile(self, file_id, location):
        cwd=os.getcwd()
        print(cwd)
        print("Downloading {0} to {1}..".format(file_id,location))
        request = self.googleService.files().get_media(fileId=file_id)
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        while done is False:
            status, done = downloader.next_chunk()
            print
            "Download %d%%." % int(status.progress() * 100)
        with io.open(location, 'wb+') as f:
            try:
                fh.seek(0)
                shutil.copyfileobj(fh.read(),f)
            except IOError:
                print("Unable to open folder..")

    def checkPermission(self,locationPath):
        if os.path.exists(locationPath):
            print(" {} Exists..".format(locationPath))
            hasAccess=os.access(locationPath, os.X_OK | os.W_OK)
            print("Access for Path :{0} : {1}".format(locationPath,hasAccess))
        else:
            print("{} folder doesn't exists..".format(locationPath))

    def download_folder(self,file_id, location, folder_name):
        print('importing dataset ')
        if not os.path.exists(location + folder_name):
            os.makedirs(location + folder_name)  # will create dataset folder if not exists
            time.sleep(10)
        location += folder_name + '/'  # dataset/ initially
        print("Our location is :",location)
        results = []
        files = self.googleService.files().list(
            pageSize='1000',
            q=f"'{file_id}' in parents",
            fields='files(id, name, mimeType)').execute()  # fetching all files with dataset as parent
        results.extend(files['files'])
        results = sorted(results, key=lambda k: k['name'])
        print("Result :", results)
        total = len(results)
        print("Total Length is :", total)
        current = 1
        # self.checkPermission("src/"+location)
        for item in results:  # iterating over each folders in dataset
            subfolder_id = item['id']
            subfolderName = item['name']
            subfoldermime_type = item['mimeType']
            print(
                f'Folder Id:{subfolder_id} Folder Name:{subfolderName} Folder Type:{subfoldermime_type} Iteration Number:({current}/{total})')
            if subfoldermime_type == 'application/vnd.google-apps.folder':
                self.download_folder(subfolder_id,location,subfolderName)  # Recursively calling each subfolder in dataset
            elif not os.path.isfile(location + subfolderName):  # location+subfolderName=dataset/Dani for ex:
                print(subfolderName)
                # self.checkPermission(location)
                self.downloadFile(subfolder_id, location)
            current += 1  # Iteration counter

    def openWeb(self):
        isOpened = webbrowser.open(
            'https://drive.google.com/drive/folders/1yh7qnA6LgJdsNGX5iTzCQJkRJGsEZ8E0?usp=sharing', new=2)
        if isOpened:
            print("Web opened..")
        else:
            print("Can't open the web..")

    def downloadDataset(self):
        print("Importing dataset folder..")
        if not os.path.exists('dataset'):
            shutil.move('C:\\Users\\User\\Desktop\\dataset', 'dataset')
        print("dataset successfully imported..")

    def cleanup(self, fullPath):
        if os.path.exists(fullPath):
            print("Deleting " + fullPath + "..")
            shutil.move(fullPath, 'C:\\Users\\User\\Desktop')
        print("{} cleaned..".format(fullPath))

driveService = GoogleDriveService()

