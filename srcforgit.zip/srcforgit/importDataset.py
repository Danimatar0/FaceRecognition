# Python program to create
# a file explorer in Tkinter
import os
from shutil import copyfile
# from the tkinter library
from tkinter import *
from tkinter import filedialog, ttk
from shutil import copyfile
from zipfile import ZipFile
from src.DBManipulation import DBManipulation
from tkinter import messagebox as mb
from PIL import Image, ImageTk

from src.faceTraining import Training
from src.quickstart import GoogleDriveService


class importPage:
    # Function for opening the
    # file explorer window

    def __init__(self, root):
        importWindow = Toplevel(root)
        importWindow.geometry('500x300')
        importWindow.resizable(0, 0)
        importWindow.wm_iconbitmap('img/import.ico')  # the img for the root, metel favicon
        importWindow.title('IMPORT SAMPLE')
        importWindow.configure(bg='#D3D3D3')
        self.oldName = ""
        self.manipulation = DBManipulation()
        self.service = GoogleDriveService()
        self.service.downloadDataset()


        # Bg img
        image = Image.open('img/import.jpg')
        self.copy_of_image = image.copy()
        photo = ImageTk.PhotoImage(image)
        self.label1 = ttk.Label(importWindow, image=photo)
        self.label1.bind('<Configure>', self.resize_image)
        self.label1.pack(fill=BOTH, expand=YES)

        # Labels
        # Create a File Explorer label
        label_file_explorer = Label(importWindow,
                                    text="File Explorer",
                                    width=100, height=4,
                                    fg="blue")
        fnameLabel = Label(importWindow, text='FIRSTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        fnameLabel.place(x=20, y=100)

        lnameLabel = Label(importWindow, text='LASTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        lnameLabel.place(x=20, y=150)

        # Storing Variables
        self.firstname = StringVar()
        self.lastname = StringVar()

        # Entries
        fnameEntry = Entry(importWindow, textvariable=self.firstname, bg="#D3D3D3")
        fnameEntry.place(x=250, y=100)
        lnameEntry = Entry(importWindow, textvariable=self.lastname, bg="#D3D3D3")
        lnameEntry.place(x=250, y=150)

        # Buttons
        self.button_explore = Button(importWindow,
                                text="Browse Files",
                                command=(lambda: self.browseFiles(label_file_explorer)))
        self.button_explore.place(x=200, y=220)

        # service = GoogleDriveService()
        # folderId = service.createFolder(str(self.firstname))
        # button_exit = Button(importWindow,
        #                      text="Exit",
        #                      command=(lambda: exit))
        # button_exit.grid(column=1, row=3)
        # button_exit.place(x=350,y=220)

        # Let the window wait for any events
        importWindow.mainloop()

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        image = self.copy_of_image.resize((new_width, new_height))
        photo = ImageTk.PhotoImage(image)
        self.label1.config(image=photo)
        self.label1.image = photo  # avoid garbage collection

    def getTargetPath(self, fileName):
        filenameZip = fileName.split("/")[-1]
        print(filenameZip)

        self.oldName = filenameZip[:-4]  # remove .zip extension
        # targetPath = fileName + "/" + self.oldName
        # return targetPath

    def browseFiles(self, label_file_explorer):
        self.fnameVal = self.firstname.get()
        self.lnameVal = self.lastname.get()
        folderId = self.service.createFolder(
            str(self.fnameVal))  # creating folder elon for ex , on drive storage in dataset main folder
        Result = self.manipulation.fetchSample(self.fnameVal)
        if Result >= 1:
            mb.showerror("Error", "This sample already exist..")
        else:
            filename = filedialog.askopenfilename(initialdir="/",
                                                  title="Select a File",
                                                  filetypes=(("Text files",
                                                              "*.txt*"),
                                                             ("all files",
                                                              "*.*")))
            print(filename)
            self.getTargetPath(filename)
            with ZipFile(filename, 'r') as zipObj:
                # Extract all the contents of zip file in current directory
                zipObj.extractall('dataset/')
                if not os.path.exists('dataset/' + self.fnameVal):
                    os.rename('dataset/' + self.oldName, 'dataset/' + self.fnameVal)
                mb.showerror('Error', self.fnameVal + 'already exist..')
            print("Folder successfully copied to destination..")
            # Change label contents
            label_file_explorer.configure(text="File Opened: " + filename)
            print("Inserting 1 row to database.. ")
            self.manipulation.insertSample(self.fnameVal, self.lnameVal, 'dataset/' + self.fnameVal)
            count=0
            for file in os.listdir('dataset/{0}'.format(self.fnameVal)):
                if file.__contains__(self.fnameVal):
                    print("Uploading {} to drive..".format(self.fnameVal))
                    count+=1
                    fullPath = "dataset/{0}/{1}{2}{3}.jpg".format(str(self.fnameVal), str(self.fnameVal), str(self.lnameVal),
                                                                  str(count))
                    self.service.uploadFile(file,fullPath,"image/jpg",folderId)
            training = Training()
            training.train()
            self.service.cleanup('dataset')

