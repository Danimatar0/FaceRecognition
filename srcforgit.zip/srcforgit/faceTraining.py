from imutils import paths
import face_recognition
import pickle
import cv2
import os
from tkinter import messagebox as mb

from src.quickstart import GoogleDriveService


class Training:

    def train(self):
        # get paths of each folder in folder named dataset
        # dataset here contains my data(folders of various persons)
        folderPaths = list(paths.list_images('dataset'))  # folderPaths contains the list of images paths in each
        # person's folder in dataset
        # print(folderPaths)
        knownEncodings = []
        knownNames = []
        # loop over the image paths
        for (i, imgPath) in enumerate(folderPaths):
            # extract the person name from the image path
            name = imgPath.split(os.path.sep)[-2]
            print("Image path :", imgPath)  # imgPath hiye each image path
            print("Name :", name)  # Name is person's firstname,=> equal folder's name
            # load the input image and convert it from BGR (OpenCV ordering)
            # to dlib ordering (RGB)
            image = cv2.imread(imgPath)  # reading the img from path
            rgbImg = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            # Use Face_recognition to locate faces
            boxes = face_recognition.face_locations(rgbImg, model='hog')  # hog is less accurate, but faster on cpu
            # compute the facial embedding for the face
            encodings = face_recognition.face_encodings(rgbImg, boxes)
            # loop over the encodings
            for encoding in encodings:
                knownEncodings.append(encoding)
                knownNames.append(name)
        # save encodings along with their names in dictionary data
        data = {"encodings": knownEncodings, "names": knownNames}
        # use pickle to save data into a file for later use
        f = open("trainer/faceEncoding.pickle", "wb")
        f.write(pickle.dumps(data))
        fileStats=os.stat("trainer/faceEncoding.pickle")
        fileSize=fileStats.st_size
        if fileSize > 0:
            mb.showinfo("Success","Model Successfully Trained.")
        else:
            mb.showerror("Error", "Unable To Train Model, Kindly Check Your Configuration..")
        print("Closing Program..")
        f.close()

# trainer=Training()
# trainer.train()
