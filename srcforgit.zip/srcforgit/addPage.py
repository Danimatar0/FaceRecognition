import os
from tkinter import *
from tkinter import ttk

from PIL import Image, ImageTk

from src.DBManipulation import DBManipulation
from src.faceDataset import Dataset
from src.faceTraining import Training
from src.quickstart import GoogleDriveService


class addPage:
    def __init__(self, root):
        self.service = GoogleDriveService()
        addWindow = Toplevel(root)
        addWindow.geometry('700x500')
        addWindow.resizable(0, 0)
        addWindow.wm_iconbitmap('img/registration.ico')  # the img for the root, metel favicon
        addWindow.title('ADD NEW SAMPLE')
        addWindow.configure(bg='#D3D3D3')
        welcLabel = Label(addWindow, text='ADD NEW SAMPLE', font=('normal', 25, 'bold'), bg='#D3D3D3')
        welcLabel.place(x=150, y=50)

        # bg img
        image = Image.open('img/addUser.png')
        self.copy_of_image = image.copy()
        photo = ImageTk.PhotoImage(image)
        self.label1 = ttk.Label(addWindow, image=photo)
        self.label1.bind('<Configure>', self.resize_image)
        self.label1.pack(fill=BOTH, expand=YES)

        # Labels
        fnameLabel = Label(addWindow, text='FIRSTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        fnameLabel.place(x=150, y=180)

        lnameLabel = Label(addWindow, text='LASTNAME', font=('arial', 14, 'bold'), bg='#D3D3D3')
        lnameLabel.place(x=150, y=230)

        # Storing Variables
        self.firstname = StringVar()
        self.lastname = StringVar()

        # Entry
        fnameEntry = Entry(addWindow, textvariable=self.firstname)
        fnameEntry.place(x=380, y=180)
        lnameEntry = Entry(addWindow, textvariable=self.lastname)
        lnameEntry.place(x=380, y=230)

        # Buttons
        captureButton = Button(addWindow, text='CAPTURE', font=('normal', 15, 'bold'), bg='#D3D3D3',
                               command=(lambda: self.captureActions()))
        captureButton.place(x=400, y=300)

    def captureActions(self):
        fnameVal = self.firstname.get()
        lnameVal = self.lastname.get()
        dataset = Dataset(self.service)
        self.service.downloadDataset()
        # self.service.download_folder(self.service.datasetId,'','dataset')
        dataset.capture(self.firstname.get(), self.lastname.get())
        # print(fnameVal)
        # print(lnameVal)
        manipul = DBManipulation()
        folderURL = "dataset/{}".format(fnameVal)
        manipul.insertSample(fnameVal, lnameVal, folderURL)
        training = Training()
        training.train()
        self.service.cleanup('dataset')

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        image = self.copy_of_image.resize((new_width, new_height))
        photo = ImageTk.PhotoImage(image)
        self.label1.config(image=photo)
        self.label1.image = photo  # avoid garbage collection
